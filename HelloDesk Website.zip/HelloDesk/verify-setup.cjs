const assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),ctx={window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync('dist/setup-core.js','utf8'),ctx);
const core=ctx.window.HelloDeskSetup;
const p=core.parse(new URLSearchParams('coverage=closed&number=existing&goals=booking,transfer,booking,unknown'));
assert.equal(p.coverage,'Outside opening hours');assert.equal(p.number,'Review my existing business number');assert.deepEqual(Array.from(p.goalCodes),['booking','transfer']);assert(core.notes(p).includes('charges need confirmation'));
const invalid=core.parse(new URLSearchParams('coverage=<script>&number=__proto__&goals=<img>,constructor,faq,faq'));
assert.equal(invalid.coverage,'To be discussed');assert.equal(invalid.numberCode,'unsure');assert.deepEqual(Array.from(invalid.goalCodes),['faq']);assert(!core.notes(invalid).includes('<'));
console.log('PASS: setup requirements use known values only; unknown URL input is ignored, duplicates removed and preferences remain qualified as requirements.');
