const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root=path.join(__dirname,'dist');
assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'packages.js'))).digest('hex'),'6c05fbbb2014fbc125d0b4afa06f0979247e5fd278d6f0e865baee5a131610d3','All prices, package deals, terms and allowances remain byte-for-byte unchanged');
const files=fs.readdirSync(root,{recursive:true}).filter(file=>file.endsWith('.html'));
const page=file=>fs.readFileSync(path.join(root,file),'utf8');
let anchors=0;
for(const file of files){
 const html=page(file);
 for(const match of html.matchAll(/href="([^"<>]+)"/g)){
  const href=match[1].replaceAll('&amp;','&');
  if(!href.startsWith('/')&&!href.startsWith('#'))continue;
  const url=new URL(href,'https://example.com/'+file);
  if(!url.hash)continue;
  const destination=url.pathname==='/'?'index.html':url.pathname.slice(1);
  if(!fs.existsSync(path.join(root,destination)))continue;
  const id=decodeURIComponent(url.hash.slice(1));if(!id)continue;
  assert(page(destination).includes('id="'+id+'"'),file+' has a broken anchor '+href);anchors++;
 }
 assert(!/\bsk_live_|\bsk_test_|-----BEGIN .*PRIVATE KEY/.test(html),'No credentials in generated pages');
 assert(html.includes('property="og:description"'),'Share metadata: '+file);
}
const home=page('index.html'),barber=page('industries/barbers.html'),practice=page('practice-booking.html');
assert.equal((home.match(/class="quality-destination /g)||[]).length,6,'Homepage keeps six direct destinations');
assert(home.includes('/barber-setup.html')&&home.includes('/practice-booking.html?industry=barber#barber-ai'));
const scripts=html=>[...html.matchAll(/<script src="([^"]+)"/g)].map(match=>match[1]);
assert.deepEqual(scripts(home),['/packages.js','/config.js','/content.js','/site.js'],'Home loads only core interaction scripts');
assert(scripts(practice).includes('/elevenlabs-voice.js')&&scripts(practice).includes('/practice-booking.js'),'Voice features load on practice page');
assert(!scripts(barber).includes('/elevenlabs-voice.js'),'No voice provider adapter on barber landing page');
assert(scripts(page('barber-setup.html')).includes('/barber-setup.js'));
assert(!scripts(page('pricing.html')).includes('/practice-booking.js'));
assert(barber.includes('not a live calendar or booking confirmation')&&barber.includes('not claims that your booking system has already passed'),'Workflow and checks are not false evidence');
assert(practice.includes('No real appointment, payment or telephone call is made'),'Voice demo limits retained');
assert(fs.readFileSync(path.join(root,'client-quality.css'),'utf8').includes('prefers-reduced-motion'),'Motion preferences respected');
console.log('PASS: complete catalogue unchanged; six direct destinations; '+anchors+' internal anchors; route-specific scripts; share metadata; truthful barber workflow and demo scope.');
