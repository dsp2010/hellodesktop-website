module.exports = ({P, esc, button, eyebrow, faq, planner = ''}) => {
  const list = items => `<ul class="package-checks">${items.map(item => `<li>${esc(item)}</li>`).join('')}</ul>`;
  const detail = (title, body) => `<details class="package-details"><summary>${esc(title)}<span aria-hidden="true">+</span></summary><div class="package-details-body">${body}</div></details>`;
  const row = (label, value) => `<div><dt>${esc(label)}</dt><dd>${esc(value)}</dd></div>`;
  const duration = minutes => `${P.number(minutes)} min`;
  const aiRows = plan => row('AI minutes / month', P.number(plan.minutes)) + row('UK SMS segments / month', P.number(plan.sms)) + row('Staff calendars', plan.calendars === 1 ? '1' : `Up to ${plan.calendars}`) + row('Small info updates / month', `${plan.infoUpdates} request${plan.infoUpdates === 1 ? '' : 's'}`);
  const websiteRows = plan => row('Website pages', plan.pages === 1 ? '1 page' : `Up to ${plan.pages} pages`) + row('Small content edits / month', duration(plan.editMinutes)) + row('Initial revision rounds', plan.revisions);
  function card(plan) {
    const ai = P.receptionistFor(plan.id), web = P.websiteFor(plan.id), bundle = plan.category === 'bundles';
    return `<article class="package-card ${plan.recommended ? 'package-recommended' : ''}" id="package-${plan.id}" aria-labelledby="title-${plan.id}">
      <div class="package-card-heading"><span class="package-badge ${plan.recommended ? '' : 'package-badge-quiet'}">${plan.recommended ? 'Recommended' : bundle ? 'Receptionist + website' : web ? 'Custom website' : 'Telephone receptionist'}</span><h3 id="title-${plan.id}">${esc(plan.shortName)}</h3><p>${esc(plan.description)}</p></div>
      <div class="package-money"><p class="package-monthly">${P.money(plan.monthly)}<span>/month</span></p><p class="package-setup">+ ${P.money(plan.setup)} one-time setup</p><p class="package-vat">${esc(P.vatNote)}</p></div>
      ${bundle ? `<p class="bundle-components"><a href="#package-${ai.id}">${esc(ai.name)}</a><span aria-hidden="true"> + </span><a href="#package-${web.id}">${esc(web.name)}</a></p><p class="bundle-saving">Save ${P.money(plan.savingMonthly)}/month <span>vs buying separately</span></p>` : ''}
      <dl class="package-allowances">${ai ? aiRows(ai) : ''}${web ? websiteRows(web) : ''}</dl>
      <div class="package-commitment">${ai ? `<p><b>Extra AI minute:</b> ${P.money(ai.extraMinute)}</p>` : ''}${web ? `<p><b>${plan.initialTermMonths}-month initial term.</b> Then monthly renewal with ${P.terms.renewalNoticeDays} days’ notice.</p>` : `<p>Setup paid before building. Subscription starts at the agreed go-live date.</p>`}</div>
      <a class="button ${plan.recommended ? 'light' : 'dark'} package-cta package-link" href="/personalise.html?plan=${plan.id}">Plan ${esc(plan.shortName)}<span aria-hidden="true">↗</span></a>
    </article>`;
  }
  function comparison(category) {
    const plans = category.planIds.map(id => P.byId[id]);
    const ai = category.id === 'ai-receptionist';
    const rows = ai ? [['AI minutes / month', p => P.number(p.minutes)], ['UK SMS segments / month', p => P.number(p.sms)], ['Staff calendars', p => p.calendars === 1 ? '1' : `Up to ${p.calendars}`], ['Extra AI minute', p => P.money(p.extraMinute)], ['Small info update requests / month', p => p.infoUpdates]] : [['Website pages', p => p.pages === 1 ? '1' : `Up to ${p.pages}`], ['Small content edits / month', p => `${p.editMinutes} minutes`], ['Initial revision rounds', p => p.revisions], ['Initial term', p => `${p.initialTermMonths} months`]];
    return detail(`Compare ${ai ? 'receptionist' : 'website'} packages`, `<div class="package-table-scroll" tabindex="0" role="region" aria-label="${ai ? 'Receptionist' : 'Website'} package comparison, scroll horizontally on small screens"><table class="package-table"><caption>${esc(category.name)} comparison — GBP; ${esc(P.vatNote)}</caption><thead><tr><th scope="col">Package details</th>${plans.map(p => `<th scope="col">${esc(p.shortName)}${p.recommended ? '<span class="comparison-recommended">Recommended</span>' : ''}</th>`).join('')}</tr></thead><tbody>${[['Monthly subscription', p => P.money(p.monthly)], ['One-time setup', p => P.money(p.setup)], ...rows].map(([label, get]) => `<tr><th scope="row">${esc(label)}</th>${plans.map(p => `<td>${esc(get(p))}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`);
  }
  const ai = P.categories.find(category => category.id === 'ai-receptionist');
  const websites = P.categories.find(category => category.id === 'websites');
  const bundles = P.categories.find(category => category.id === 'bundles');
  const extraSMS = P.addOns.find(service => service.id === 'extra-sms');
  const transfer = P.addOns.find(service => service.id === 'human-transfer');
  const websiteIncluded = `All website packages include one standard domain with annual registration or renewal up to ${P.money(P.terms.domainAnnualAllowance)}, hosting management, HTTPS and source-code backups.`;
  return `<section class="wrap page-intro package-intro">
    ${eyebrow('GOOD CONVERSATIONS. A BETTER ONLINE PRESENCE.')}
    <h1>Your business.<br><em>Your next chapter.</em></h1>
    <p class="intro">AI telephone receptionists and custom websites for UK businesses. Choose one service or bring them together, with clear allowances and setup costs.</p>
    <p class="package-intro-note">All prices in GBP. ${esc(P.vatNote)}</p>
    <nav class="package-category-nav" aria-label="Pricing categories">${P.categories.map((category, index) => `<a href="#${category.id}"><span aria-hidden="true">0${index + 1}</span>${esc(category.name)}<span aria-hidden="true">↓</span></a>`).join('')}</nav>
    <p class="package-preview-note">Choose a package to prepare your setup brief. Online checkout is not connected yet; nothing is ordered, booked or submitted by this preview.</p>
  </section>
  <section class="wrap package-section" id="${ai.id}" aria-labelledby="ai-pricing-title">
    <div class="package-section-heading"><div>${eyebrow('01 / THE FIRST HELLO')}<h2 id="ai-pricing-title">${esc(ai.name)}</h2><p>${esc(ai.description)}</p></div><p>Especially suited to barbers and salons. We agree your call flow and supported integrations before go-live.</p></div>
    <div class="package-grid package-grid-four">${ai.planIds.map(id => card(P.byId[id])).join('')}</div>
    <div class="package-important"><p>${esc(P.terms.calendar)}</p><p>${esc(P.terms.sms)} Extra UK SMS: ${esc(P.addOnPrice(extraSMS))}. Connected human transfer: ${esc(P.addOnPrice(transfer))} on standard UK routes.</p></div>
    ${detail('Included in every receptionist package', list(P.receptionistFeatures) + `<p>${esc(P.terms.availability)}</p><p>Booking, changes and cancellations require a supported, connected integration. Your agreed scope is tested before go-live. The practice demo does not make real bookings.</p>`)}
    ${detail('What setup and small information updates include', `<div class="package-detail-columns"><div><h3>Your setup</h3>${list(P.receptionistSetupFeatures)}<p>${esc(P.terms.receptionistSetup)}</p></div><div><h3>Keeping answers current</h3><p>${esc(P.terms.updates)}</p><p>Your package’s request allowance is shown above. Human support operates during agreed business hours; no specific response or uptime guarantee is included here.</p></div></div>`)}
    ${comparison(ai)}
    ${planner ? `<details class="usage-disclosure"><summary>Estimate your monthly AI call minutes <span aria-hidden="true">+</span></summary>${planner}</details>` : ''}
  </section>
  <section class="wrap package-section" id="${websites.id}" aria-labelledby="website-pricing-title">
    <div class="package-section-heading"><div>${eyebrow('02 / YOUR BUSINESS, ONLINE')}<h2 id="website-pricing-title">${esc(websites.name)}</h2><p>${esc(websites.description)}</p></div><p>Custom design, clear information and an easy next step for your customers.</p></div>
    <div class="package-grid">${websites.planIds.map(id => card(P.byId[id])).join('')}</div>
    <div class="package-important"><p><b>${esc(P.websiteTerm)}</b></p><p>${esc(websiteIncluded)}</p></div>
    ${detail('Included in every website package', list(P.websiteFeatures))}
    ${detail('Domains, content and the agreed scope', list(P.websiteScope) + `<p>${esc(P.terms.agreement)}</p>`)}
    ${comparison(websites)}
  </section>
  <section class="wrap package-section" id="${bundles.id}" aria-labelledby="bundle-pricing-title">
    <div class="package-section-heading"><div>${eyebrow('03 / BETTER TOGETHER')}<h2 id="bundle-pricing-title">${esc(bundles.name)}</h2><p>${esc(bundles.description)}</p></div><p>The same component allowances, with one combined monthly price.</p></div>
    <div class="package-grid package-bundle-grid">${bundles.planIds.map(id => card(P.byId[id])).join('')}</div>
    <div class="package-important"><p><b>${P.terms.websiteInitialTermMonths}-month initial term because every bundle includes a website.</b> Then monthly renewal with ${P.terms.renewalNoticeDays} days’ notice. ${esc(P.vatNote)}</p><p>Bundles retain the AI minutes, SMS segments, calendar limits, information updates, website pages, editing allowance and initial revision rounds of their component packages. Extra AI minutes are charged at the included receptionist package’s rate.</p><p>${esc(P.terms.receptionistSetup)}</p></div>
  </section>
  <section class="wrap package-section package-extras" id="additional-services" aria-labelledby="extras-title">
    <div class="package-section-heading"><div>${eyebrow('A LITTLE MORE, WHEN YOU NEED IT')}<h2 id="extras-title">Additional services</h2><p>Add only what fits your agreed setup.</p></div><p>All prices in GBP. ${esc(P.vatNote)}</p></div>
    <div class="package-table-scroll" tabindex="0" role="region" aria-label="Additional services and prices, scroll horizontally on small screens"><table class="package-table package-addon-table"><caption>Optional services and usage charges</caption><thead><tr><th scope="col">Service</th><th scope="col">Price</th><th scope="col">Important detail</th></tr></thead><tbody>${P.addOns.map(service => `<tr><th scope="row">${esc(service.name)}</th><td>${esc(P.addOnPrice(service))}</td><td>${esc(service.id === 'support' ? `Minimum ${service.minimumMinutes} minutes.` : service.detail)}</td></tr>`).join('')}</tbody></table></div>
    <p class="package-extras-note">${esc(P.terms.paymentLinks)}</p>
    <details class="package-details package-outright"><summary>Prefer to buy your website outright?<span aria-hidden="true">+</span></summary><div class="package-details-body"><div class="outright-options">${P.outright.map(option => `<div><h3>${esc(option.label)}</h3><p>From <b>${P.money(option.from)}</b></p></div>`).join('')}</div><p>${esc(P.terms.outright)} ${esc(P.vatNote)}</p><p>We agree the scope, ownership and handover in your service agreement.</p></div></details>
  </section>
  <section class="wrap package-section package-faq" aria-labelledby="package-questions-title"><div class="package-section-heading"><div>${eyebrow('THE DETAILS THAT MATTER')}<h2 id="package-questions-title">Before we get started</h2></div></div>${faq([
    ['When do I pay for receptionist setup?', P.terms.receptionistSetup + ' We agree the supported integration and test calls before handover.'],
    ['What does a staff calendar mean?', P.terms.calendar + ' Your chosen receptionist package sets the included number; additional calendars need a supported integration.'],
    ['What happens if I use more minutes or SMS?', 'Extra AI minutes use the rate shown on your receptionist package. Extra UK SMS costs ' + P.addOnPrice(extraSMS) + '. ' + P.terms.sms + ' Usage is summarised monthly.'],
    ['Is answering available outside business hours?', P.terms.availability],
    ['How long is the website or bundle commitment?', P.websiteTerm + ' Bundles have the same initial term because they include a website. ' + P.terms.agreement],
    ['Does this preview book appointments or take payment?', 'No. The barber voice demo uses practice information, and the setup brief stays on your device. Live bookings need the agreed supported integration. Online checkout and enquiry delivery are not connected in this preview.']
  ])}</section>
  <section class="wrap package-final"><div class="final-cta"><div><h2>Let’s find your fit.</h2><p>Choose your service, outline your business and keep a brief for your setup discussion.</p></div>${button('/personalise.html', 'Prepare your setup brief')}</div></section>`;
};
