const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

class Element {
  constructor(tag = 'div') { Object.assign(this, {tagName: tag, value: '', textContent: '', hidden: false, disabled: true, dataset: {}, attributes: {}, children: [], events: {}, focused: false}); }
  set innerHTML(_) { throw new Error('Visitor-supplied values must not be rendered as HTML'); }
  addEventListener(name, callback) { (this.events[name] ??= []).push(callback); }
  fire(name) { for (const callback of this.events[name] || []) callback({target: this, preventDefault() {}}); }
  setAttribute(name, value) { this.attributes[name] = value; }
  removeAttribute(name) { delete this.attributes[name]; }
  append(...elements) { this.children.push(...elements); }
  replaceChildren(...elements) { this.children = elements; }
  focus() { this.focused = true; }
  reset() {}
  remove() { this.removed = true; }
}
const testNames = ['Correct service, staff and time', 'No double booking', 'Confirmation follows calendar acceptance', 'Change the correct appointment', 'Cancel the correct appointment', 'A clear route to the team', 'No availability or connection failure', 'The real telephone journey'];
function harness(query = '') {
  const selectors = ['barber-setup-form', 'barber-shop-name', 'barber-platform', 'barber-business-number', 'barber-website', 'barber-services', 'barber-availability', 'barber-changes', 'barber-fallback', 'barber-preferences', 'barber-test-notes', 'barber-package', 'barber-package-summary', 'barber-review', 'barber-test-status', 'barber-step-navigation', 'barber-step-status', 'barber-back', 'barber-next', 'barber-download', 'barber-reset', 'barber-setup-error', 'barber-save-status', 'barber-step-title-1', 'barber-step-title-2', 'barber-step-title-3'];
  const elements = new Map(selectors.map(id => ['#' + id, new Element()]));
  const panels = [1, 2, 3].map(step => { const element = new Element(); element.dataset.barberStep = String(step); return element; });
  const links = [1, 2, 3].map(step => { const element = new Element('button'); element.dataset.barberStepLink = String(step); return element; });
  const tests = testNames.map(name => { const element = new Element('select'); element.dataset.testName = name; element.value = 'not-tested'; return element; });
  const timers = new Map();
  let timerId = 0, saved, downloadClicked = false, revoked = [], transmissions = 0;
  class LocalURL extends URL {}
  LocalURL.createObjectURL = blob => { saved = blob; return 'blob:barber-setup'; };
  LocalURL.revokeObjectURL = url => revoked.push(url);
  const block = () => { transmissions++; throw new Error('The barber worksheet must remain page-only'); };
  const window = {};
  Object.defineProperty(window, 'localStorage', {get: block});
  Object.defineProperty(window, 'sessionStorage', {get: block});
  const document = {
    querySelector: selector => elements.get(selector) || null,
    querySelectorAll: selector => selector === '[data-barber-step]' ? panels : selector === '[data-barber-step-link]' ? links : selector === '[data-barber-test]' ? tests : [],
    body: {append() {}},
    createElement(tag) { const element = new Element(tag); if (tag === 'a') element.click = () => { downloadClicked = true; }; return element; }
  };
  const context = {window, document, location: {search: query}, URLSearchParams, URL: LocalURL, Blob,
    fetch: block, navigator: {sendBeacon: block}, localStorage: {setItem: block, getItem: block}, sessionStorage: {setItem: block, getItem: block},
    setTimeout(callback, duration) { const id = ++timerId; timers.set(id, {callback, duration}); return id; }, clearTimeout(id) { timers.delete(id); }
  };
  vm.createContext(context);
  vm.runInContext(fs.readFileSync('dist/packages.js', 'utf8'), context);
  vm.runInContext(fs.readFileSync('dist/barber-setup.js', 'utf8'), context);
  return {el: selector => elements.get(selector), P: window.HELLODESK_PACKAGES, panels, links, tests, timers, revoked,
    get transmissions() { return transmissions; },
    async download() { elements.get('#barber-download').fire('click'); assert(downloadClicked); assert(saved); return saved.text(); }
  };
}

async function main() {
  const h = harness('?plan=ai-growth&barber-shop-name=Must%20not%20import&barber-platform=Invented');
  assert.equal(h.el('#barber-package').value, 'ai-growth');
  assert.equal(h.el('#barber-shop-name').value, '', 'Only the known package ID may be imported from the URL');
  assert.equal(h.el('#barber-platform').value, '');
  assert.equal(h.el('#barber-package-summary').textContent, h.P.summary('ai-growth').join(' '));
  assert.equal(h.el('#barber-download').disabled, false);
  assert.equal(h.el('#barber-reset').disabled, false);
  assert.equal(h.el('#barber-step-navigation').hidden, false);
  assert.deepEqual(h.panels.map(panel => panel.hidden), [false, true, true]);
  assert(h.links.every(link => link.disabled === false));
  assert(h.tests.every(test => test.value === 'not-tested'));
  assert(h.el('#barber-test-status').textContent.includes('No live tests have been reported'));

  h.el('#barber-next').fire('click');
  assert.deepEqual(h.panels.map(panel => panel.hidden), [true, false, true]);
  h.el('#barber-services').value = '<script>alert("not HTML")</script> — approved service information';
  h.el('#barber-shop-name').value = 'An example & <shop>';
  h.el('#barber-platform').value = 'To confirm';
  h.el('#barber-next').fire('click');
  assert.deepEqual(h.panels.map(panel => panel.hidden), [true, true, false]);
  const reviewText = h.el('#barber-review').children.map(row => row.children.map(child => child.textContent).join(': ')).join('\n');
  assert(reviewText.includes('An example & <shop>'));
  assert(reviewText.includes('<script>alert("not HTML")</script>'));
  assert(h.el('#barber-step-title-3').focused);
  const untested = await h.download();
  assert(untested.includes('Barber shop: An example & <shop>'));
  assert(untested.includes('Growth Receptionist (ai-growth)'));
  assert(untested.includes('£349/month + £499 one-time setup.'));
  assert(untested.includes('750 AI minutes and 300 UK SMS segments/month.'));
  assert.equal((untested.match(/NOT YET TESTED/g) || []).length, 8);
  assert(!untested.includes('MANUALLY REPORTED PASS'));
  assert(untested.includes('Nothing has been submitted to HelloDesk'));
  assert(untested.includes('does not run them or independently verify any result'));
  assert(untested.includes('No service is activated by this document'));
  assert.equal(h.transmissions, 0);
  for (const {callback, duration} of h.timers.values()) if (duration === 10000) callback();
  assert(h.revoked.includes('blob:barber-setup'));

  h.tests[0].value = 'passed';
  h.tests[0].fire('change');
  h.tests[1].value = 'needs-work';
  h.tests[1].fire('change');
  h.tests[2].value = 'invented-pass';
  h.tests[2].fire('change');
  assert(h.el('#barber-test-status').textContent.includes('2 of 8 results entered manually; 1 marked as needing work'));
  const reported = await h.download();
  assert.equal((reported.match(/MANUALLY REPORTED PASS — not independently verified/g) || []).length, 1);
  assert.equal((reported.match(/NEEDS WORK/g) || []).length, 1);
  assert.equal((reported.match(/NOT YET TESTED/g) || []).length, 6);

  h.el('#barber-package').value = 'bundle-pro';
  h.el('#barber-package').fire('change');
  const bundle = await h.download();
  assert(bundle.includes('£799/month + £1,299 one-time setup.'));
  assert(bundle.includes('1,500 AI minutes and 600 UK SMS segments/month.'));
  assert(bundle.includes('Up to 10 website pages; 120 minutes of small content edits/month'));
  assert(bundle.includes('Save £49/month'));
  assert(bundle.includes('12-month initial term'));

  h.el('#barber-reset').fire('click');
  assert.equal(h.el('#barber-shop-name').value, 'An example & <shop>', 'First clear click is a reversible warning');
  h.el('#barber-reset').fire('click');
  assert.equal(h.el('#barber-shop-name').value, '');
  assert.equal(h.el('#barber-services').value, '');
  assert.equal(h.el('#barber-package').value, '');
  assert(h.tests.every(test => test.value === 'not-tested'));
  assert.deepEqual(h.panels.map(panel => panel.hidden), [false, true, true]);

  for (const query of ['?plan=constructor', '?plan=__proto__', '?plan=unknown', '?plan=web-business']) {
    const unknown = harness(query);
    assert.equal(unknown.el('#barber-package').value, '');
    const text = await unknown.download();
    assert(text.includes('To discuss — no package selected.'));
    assert(!text.includes('£'), 'An invalid/unsupported package must not invent charges');
    assert.equal(unknown.transmissions, 0);
  }
  const generic = await harness('').download();
  assert(generic.includes('Barber shop: To agree'), 'A generic worksheet can be saved without supplying a prospect name');
  const limited = harness();
  limited.el('#barber-services').value = 'x'.repeat(2200);
  assert(!(await limited.download()).includes('x'.repeat(1801)), 'Export respects input limits');

  const template = require('./barber-setup.cjs')({P: h.P, C: {}, esc: text => String(text).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char])), button: () => '', eyebrow: () => ''});
  assert.equal((template.match(/<h1>/g) || []).length, 1);
  assert.equal((template.match(/data-barber-test=/g) || []).length, 8);
  assert(!template.includes('<section data-barber-step="2" hidden'), 'All worksheet sections remain readable without JavaScript');
  assert(template.includes('Nothing is submitted to HelloDesk'));
  assert(!/\sname="/.test(template), 'Visitor details must not become form query parameters without JavaScript');
  assert(template.includes('id="barber-download" type="button" class="button dark" disabled'));
  console.log('PASS: generic barber worksheet, shared package allowances, explicit manual test results, three-step navigation, safe text rendering, input limits, reset and local-only download. No network, storage, microphone, real booking or service activation.');
}
main().catch(error => { console.error(error); process.exitCode = 1; });
