# HelloDesk integration and launch handoff

## Current commercial packages — October 2026

The authoritative package catalogue is now dist/packages.js: four AI receptionist packages, three website subscriptions and three component-based bundles, plus extras and outright website offers. pricing-page.cjs renders it and dist/config.js / dist/content.js derive compatibility views. Older implementation notes below describe earlier preview stages; the current catalogue supersedes statements about unconfirmed allowances or the former package structure.

Package CTAs preserve the canonical plan ID in the local setup brief, which shows and exports current shared prices, setup fees and allowances. Website/bundle initial commitment and renewal notice are stated near pricing. The owner supplied this commercial scope; supported live integrations still require customer-specific configuration and tests. The browser barber demonstration makes practice bookings only. No live calendar, n8n workflow or telephone connection is included in this source.

Online checkout stays disabled: no Stripe links or complete agreements are supplied. The intended sequence is setup payment before building and subscription from the agreed go-live date; do not enable a monthly-only link that silently contradicts it. Public contact and enquiry destinations remain unconfigured. Preserve the existing site's custom audience, including its external viewer, during updates.


## What is working

`/practice-booking.html` is a separate guided booking sandbox. The user explicitly chose browser practice. It uses browser speech recognition/playback and a predefined booking flow, not an LLM or the real telephone assistant. All nine industries have fictional sample services and the next three UK calendar dates with three sample times. Nothing contacts a real business, calendar, email, SMS or payment service.

Start voice practice speaks each prompt and automatically opens the next listening turn after playback ends. Capture stops before the next spoken reply. Indicators follow actual speech/audio events. Speak your answer offers a manual retry; End practice aborts capture, cancels playback and clears all practice details. Switching business clears the session, leaving the page clears it, and backgrounding pauses audio without automatic restart. Hear prompts, use buttons never requests a microphone and can complete the same practice flow. Permission, audio capture and network failures leave the on-screen choices usable. The earlier microphone problem is not claimed fixed: actual microphone availability still depends on the browser/device.

`practice-booking.cjs`, `dist/practice-booking-core.js`, `dist/practice-booking.js` and `dist/practice-booking.css` implement this sandbox. An explicit final confirmation is required; the result is marked PRACTICE ONLY with a PRACTICE-prefixed reference. Its downloadable text receipt repeatedly states that no real appointment was made. The homepage's first card now leads to Voice practice; written examples remain in navigation. `node verify-practice-booking.cjs` covers all nine flows, spoken choice parsing, corrections, confirmation and the actual UI controller with mocked speech lifecycle events. It never uses a real microphone or calendar. Connect the finished AI separately; do not describe the predefined practice engine as a live AI provider.

The optional `/guide.html` flow collects non-identifying setup requirements in three steps: business/goals, call coverage/number needs/optional volume, and a review. The homepage's existing Your setup card leads to it; direct brief links remain available. It carries only whitelisted choice IDs and valid numeric estimates in the brief-builder URL. Coverage and requirements prefill the local brief and are included in its download. It does not recommend an unconfirmed paid tier, submit an enquiry, persist a customer record or connect a telephone number.

`setup-guide.cjs`, `dist/setup-guide.js`, `dist/setup-core.js` and `dist/guide.css` implement the guide and shared preference parsing. `node verify-setup.cjs` checks safe preference import; `node verify-experience.cjs` checks the imported requirements appear in the export. Telephone FAQs now have a progressive-enhancement search (`dist/faq-search.js`) with result counts, clear/reset and an explicit empty state. All questions remain readable when JavaScript is unavailable.

The customer-facing design uses the fixed HelloDesk green/cream palette and a consistent SVG industry icon set (`industry-icons.cjs`). `dist/polish.css` refines the existing base styles. The six-card homepage now leads to call examples, industries, pricing, setup information, the founding story and the brief builder. Internal pilot guidance and the temporary browser voice demo remain at their original URLs but are not promoted in the main sales journey.

Industry pages use a compact price band rather than repeating all three full plan cards. Pricing cards render confirmed allowance fields only; unconfirmed entries remain visible in the expandable comparison and the pre-launch disclosure. The usage estimator is also expandable. Until real booking is connected, shared setup links and plan dialogs go straight to the local brief builder and preserve the selected business type and plan.

- 25 static pages, including nine industry URLs, /practice-booking.html, /guide.html, /calls.html, /contact.html, /demo.html, /personalise.html and /pilot.html.
- Business-type selectors, relevant questions and industry-specific FAQs.
- Prices from one configuration: Starter £99, Growth £199, Scale £249 monthly.
- Plan detail dialogs and a comparison table with explicit unconfirmed allowances.
- Conditional calendar/form integration and a working local setup-brief alternative while booking is unavailable. Disabled enquiry fields remain hidden without a destination.
- Personalised visual telephone greeting preview in the fixed HelloDesk colour scheme, business-specific example question, draft approved answer, coverage preferences and text-file export. Entries are not sent or stored by HelloDesk.
- A call-minute estimator with input validation and transfer of estimates into the local setup brief. No invented ROI or plan recommendation.
- Pilot discussion checklist and evidence standards without fabricated customers, reviews or metrics.
- Honest founding story; missing team bios, video, contact address and testimonials are not rendered.
- User-approved temporary voice demonstration using browser speech APIs and predefined fictional business answers. No chat input, fake reviews, payment confirmation or live appointments.

## Edit locations

`sales-pages.cjs` supplies the call examples and practical phone FAQs, conditional contact options, visible plan allowance summaries and the four-step purchase/setup journey. `dist/sales.js` switches industry examples and opens direct links to plan comparison details. Without a verified booking destination, shared demo links say "Prepare a demo"; with a valid calendar or enquiry receiver, they say "Book a demo". The compact six-card homepage is retained.

Real sample audio is configured per industry in `callSamples`. Supply a public HTTPS `url`, accurate `transcript`, `verified: true` after reviewing the actual product recording, and `consentConfirmed: true` after confirming permission to publish the voices and information in it. No audio is rendered until all four are present. Current samples are clearly marked written fictional scripts. Do not label synthetic or illustrative recordings as evidence from the real product. `node verify-sales.cjs` checks this publication gate and transcript escaping.

The contact page renders a public email or calendar only when configured. Without these, it links to the local brief builder and explicitly says no enquiry is sent. No new receiver, mailbox or Stripe account has been created.

The confirmed product is a **telephone answering assistant**, not an installed website chat widget. The browser voice demonstration is only a separate temporary demonstration. No telephone number, carrier, phone provider, call-routing backend or live phone assistant has been supplied or connected. When the real product arrives, map each business type to its actual provider-side telephone agent. Forwarding, transfers, call recording, retention, voicemail behaviour and real incoming-call tests must be agreed and implemented with that provider. The existing iframe adapter below only supports browser demonstrations; it does not establish telephone service.

`marketing.cjs`: new homepage, personalisation, plan guidance, usage estimator, booking fallback and pilot sections. `dist/experience.js`: local preview, download and calculator interactions. `node verify-experience.cjs` tests the exported brief and industry isolation.

`dist/config.js`: prices, plan allowances, Stripe links, booking destination, terms, real trust information, voice privacy and assistant mappings. Public values only.

`dist/content.js`: business types, URLs, example questions, scenarios and industry FAQs.

`build.cjs`: page templates; run `node build.cjs` after editing templates or configuration/content, then `node verify.cjs`. Generated HTML is checked into the source repo and packaged from dist/.

`dist/site.js` and `dist/site.css`: interactive behavior and responsive styling.

## Connect the real talking assistants

### Temporary browser demo (approved by the user)

`browserDemo.enabled` is true. `dist/browser-voice.js` provides real browser speech recognition and playback, with fictional sample information for all nine types. It is not a generative AI model. A verified real provider for the selected type takes precedence. Disable the temporary demos globally with `browserDemo.enabled: false` when appropriate.

Each listening turn starts only after an explicit button click. Recognition stops before replying. Ask another question starts the next turn; there is no automatic microphone restart. The mic indicator follows the actual audiostart/audioend events, and speaking animation follows the utterance start/end events. End, switch, page exit and backgrounding abort recognition, cancel playback and clear captions. No transcript persistence or audio recording code exists. The browser may use an external speech service, so the site discloses this before starting; its provider's policies still apply.

The no-microphone Hear an example control exercises synthesis only. Unsupported recognition, denied permission, missing microphone, service/network failures and timeouts have explicit states. English playback voices come from the device. No credentials are needed for the browser demo. Real provider audio processing remains separately unconfirmed.

Map each supplied bot explicitly to barber, salon, restaurant, cafe, shop, ecommerce, cleaning, gardening or trades. No generic fallback is used.

The prepared iframe bridge requires `embedUrl`, `verified: true`, `protocol: 'hellodesk-v1'`, and a nonempty confirmed `voicePrivacy` disclosure. Keep these disabled until the actual provider passes integration testing. A generic provider URL may not implement this bridge; add a provider SDK adapter or a controlled wrapper as necessary.

Parent sends `{ type: 'hellodesk:start', sessionId, industry, businessType }` after the visitor starts and the frame loads. The frame should verify its parent origin and request a microphone only for this explicit start. It must return `{ type: 'hellodesk:state', sessionId, state, code? }` using an exact permitted parent origin. Supported states: ready, permission, connected, listening, speaking, ended, error. Error codes: permission_denied, no_microphone, unsupported, network, timeout, provider.

The parent accepts messages only from the configured URL origin, exact frame window, and current session ID. No listening or speaking animation runs on an arbitrary timer. A 25-second initial connection timeout closes an unresponsive frame. Parent sends `{ type: 'hellodesk:stop', sessionId }` and removes the frame on ending, switching or page exit. Provider must stop audio tracks and its remote session, including when its frame unloads. Verify this on the real service; mock lifecycle tests are not proof of real microphone cleanup.

Before activation test microphone grant/denial, missing mic, unsupported browser, interruption, actual speaking/listening states, repeated start/end, business switching, page exit, and mobile Safari/Chrome. Publish actual recording, transcript and retention information. Never expose private credentials in the browser.

## Book a demo

Choose one route in config:

1. Set `booking.calendarUrl` to the real HTTPS booking calendar. The calendar CTA appears and the preview form is hidden. Confirmation happens in the calendar service.
2. Set `booking.endpoint` to a verified HTTPS JSON receiver, `booking.responseMessage` to the confirmed next steps, and `terms.privacyUrl` to a real privacy notice. The form sends name, business, email, group, industry, optional website, help, and optional selected plan. Receiver must validate/rate-limit requests, persist/deliver them, and support CORS if on another origin. Return a 2xx JSON response with `{ accepted: true, reference: 'real-record-id' }` only after accepting the enquiry. The UI displays success only with that confirmation. Network/timeout errors preserve input and disclose delivery uncertainty. Implement receiver-side deduplication before launch.

With no destination, fields stay disabled and hidden, no details are transmitted or stored, and there is no success message. A separate local brief builder provides a useful action and explicitly does not book or request a callback. No actual form backend is deployed with this static site.

## Plans, Stripe and onboarding

Populate each plan's minutes, assistants, locations, setup, knowledge, integrations, support, reporting, overage, setupFee, commitment. Use confirmed values based on actual costs; numeric zero is allowed. Supply tax, cancellation, activation timing, terms URL and privacy URL. Update the pre-launch copy in build.cjs when opening sales, then regenerate.

Create monthly subscription Payment Links matching the displayed prices and intended currency. Only public buy.stripe.com links are accepted. Checkout stays hidden unless salesOpen is true and the selected plan and terms are filled. Test Stripe test-mode checkout before enabling live links. Configure Stripe to collect business onboarding information and deliver real post-payment instructions.

The Stripe link includes a non-sensitive plan/business-type client_reference_id; it is not proof of identity or payment. The static payment-return.html page never verifies a payment, provisions access, or activates an assistant. It supports ?status=cancelled and ?status=failed messages for navigation only. Verify payment in Stripe for manual fulfilment. Automated activation needs a separate server with verified, idempotent Stripe webhooks, customer/subscription mapping and authenticated onboarding; this has not been implemented without the real product and account details.

## Real trust content

Add supplied team names/bios to trust.team, a real public contact email to trust.email, a direct HTTPS product video file to trust.videoUrl, and approved testimonials to trust.testimonials. Team entries use name/bio; testimonials use quote/name/business. Nothing is fabricated. Add captions/transcript when a real video is supplied. The existing story uses only the known fact that two friends are building the product.

## Missing before customer launch

- Actual voice bot embeds/SDK details, mapping and verified features.
- Recording/transcription/retention information and privacy notice.
- Confirmed allowances, usage costs, fees, support scope, taxes, terms and delivery timing.
- Stripe links; verified fulfilment/onboarding process.
- Calendar URL or working enquiry endpoint and response expectations.
- Real team details, business contact address, product video and any genuine pilot evidence.
- Final name and any requested audience/domain change; preserve the current audience unless the owner requests otherwise.

## Verification and limits

`node verify.cjs` checks 25 pages, internal navigation/assets, unique routes, exact prices, disabled commerce integrations and the real-provider voice controller in a mocked DOM. It tests trusted/stale/spoofed session events, business isolation, ending/switch cleanup, permission error and initial timeout. `node verify-browser-voice.cjs` covers all nine sample profiles, capture-to-playback handoff, manual next-turn behavior, real-event-driven indicators, no-mic playback, cancellation, stale callbacks, permission errors and timeouts using mocked speech APIs.

The current local demo returned HTTP 200. Browser preview now works: example playback reached the actual speaking state, completed to the next-question state, End cleared captions, industry switching changed questions and assistant labels, and the mobile-width demo had no horizontal overflow. Desktop and phone-width layouts were visually inspected. A real microphone capture test was not performed on the user's device. Real AI provider, booking delivery and payments remain unconnected and untested end to end.
# ElevenLabs barber voice demo — connected October 2026

The browser demo now has one real agent, `HelloDesk Barber Demo`, public Agent ID `agent_8201m5n282qfe5abth4gdcctr0zc`. It uses the owner's saved `middle ages man` voice (Voice ID `OfrZNMutP85VtVvCYGhH`). These public identifiers are not API keys.

The official widget is opened from `/practice-booking.html#barber-ai`. The primary button first performs an explicit local microphone-access check. Every test stream track is stopped immediately; no test recording is made and the stream is never sent to ElevenLabs. Only after a successful check is the provider script loaded and its voice panel opened. The widget's own start button and consent screen then begin the real AI conversation. A blocked check displays a recoverable local error, Windows/browser steps and a copyable canonical URL for Chrome or Edge. The website cannot change OS or host-app microphone permissions.

Preflight attempts time out after 20 seconds. Cancelling, backgrounding, leaving the page or starting the separate guided practice invalidates the attempt; late permission grants still stop all returned tracks. Retrying always rechecks access. No microphone or provider load happens automatically. Copying the browser URL occurs only on the copy-button click, with a manual-select fallback if clipboard access fails.

The separate legacy `HELLODESK_VOICE` iframe protocol does not apply to this widget. Only `HELLODESK_CONFIG.voiceAgents.barber` is connected; do not use the barber ID for other industries.

Published ElevenLabs configuration: voice-only widget with captions, text input disabled, interruptible greeting, expressive speech enabled, and a fictional barber/practice-booking prompt. No real booking, phone, payment, SMS or email service is connected. Audio recording is disabled; transcripts have 7-day retention. Maximum conversation duration is 300 seconds, silence timeout 30 seconds, daily call limit 20, concurrency limit 1, bursting and queuing disabled. The host allowlist is `hellodesk-business-chatbots-darsh.wisesun14.chatgpt.site`, with missing Origin headers rejected. Authentication remains off for this public demo agent; the HelloDesk website retains its existing custom audience. These demo limits are separate from the advertised software subscription plans.

Future domain changes require updating the ElevenLabs allowlist. Plan allowances and payments remain unconnected. Review this demo's account usage before inviting external visitors. A complete spoken end-to-end conversation still requires a user with a working microphone; automated lifecycle checks do not verify voice quality or microphone availability.

