const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync('dist/elevenlabs-voice.js', 'utf8');
const AGENT = 'agent_8201m5n282qfe5abth4gdcctr0zc';
const SCRIPT = 'https://unpkg.com/@elevenlabs/convai-widget-embed@0.21.3';
const LIVE_URL = 'https://hellodesk-business-chatbots-darsh.wisesun14.chatgpt.site/practice-booking#barber-ai';
class Element {
  constructor(tag = 'div') { Object.assign(this, {tagName: tag, hidden: false, disabled: false, textContent: '', dataset: {}, attributes: {}, children: [], events: {}, parent: null, focused: false, selected: false, value: ''}); }
  setAttribute(key, value) { this.attributes[key] = value; }
  getAttribute(key) { return this.attributes[key]; }
  addEventListener(name, callback) { (this.events[name] ??= []).push(callback); }
  trigger(name) { for (const callback of this.events[name] || []) callback({target: this}); this['on' + name]?.({target: this}); }
  click() { if (!this.disabled) this.trigger('click'); }
  append(...nodes) { for (const node of nodes) { node.parent = this; this.children.push(node); } }
  replaceChildren(...nodes) { for (const node of [...this.children]) node.remove(); this.append(...nodes); }
  remove() { this.removed = true; if (this.parent) this.parent.children = this.parent.children.filter(child => child !== this); this.parent = null; }
  focus() { this.focused = true; }
  select() { this.selected = true; }
}
function deferred() { let resolve, reject; const promise = new Promise((yes, no) => { resolve = yes; reject = no; }); return {promise, resolve, reject}; }
function microphoneStream(count = 2, throwingTrack = false) {
  const tracks = Array.from({length: count}, (_, i) => ({stops: 0, stop() {this.stops++; if (throwingTrack && i === 0) throw new Error('Track failed to stop');}}));
  return {tracks, getTracks: () => tracks};
}
const flush = async () => { await Promise.resolve(); await Promise.resolve(); await Promise.resolve(); };
function harness({config = {provider: 'elevenlabs', agentId: AGENT, enabled: true}, missingPanel = false, supported = true, query = '', secure = true, media = true, policy, getUserMedia, clipboard = true} = {}) {
  const selectors = ['barber-ai-panel', 'barber-ai-open', 'barber-ai-close', 'barber-ai-status', 'barber-ai-mount', 'guided-practice', 'practice-end', 'practice-start', 'practice-buttons', 'barber-mic-error', 'barber-mic-error-title', 'barber-mic-error-message', 'barber-mic-help', 'barber-mic-copy', 'barber-mic-copy-status', 'barber-mic-link'];
  const elements = Object.fromEntries(selectors.map(id => ['#' + id, new Element()]));
  elements['#barber-mic-error'].hidden = true;
  elements['#barber-mic-link'].value = LIVE_URL;
  const head = new Element('head'), events = {}, windowEvents = {}, timers = new Map(), definitions = new Map();
  const definitionWaiters = [], scripts = [], widgets = [], streams = [], copied = [], micArguments = [];
  let timerId = 0, guidedEnds = 0, microphoneRequests = 0;
  elements['#practice-end'].addEventListener('click', () => guidedEnds++);
  const registry = {get: name => definitions.get(name), whenDefined: name => definitions.has(name) ? Promise.resolve() : new Promise(resolve => definitionWaiters.push({name, resolve}))};
  const navigator = {};
  if (media) navigator.mediaDevices = {getUserMedia(constraints) {
    microphoneRequests++; micArguments.push(JSON.parse(JSON.stringify(constraints)));
    if (getUserMedia) return getUserMedia();
    const stream = microphoneStream(); streams.push(stream); return Promise.resolve(stream);
  }};
  if (clipboard) navigator.clipboard = {writeText: async text => {if (clipboard === 'reject') throw new Error('denied'); copied.push(text);}};
  const window = {HELLODESK_CONFIG: {voiceAgents: {barber: config, salon: {provider: 'elevenlabs', agentId: 'agent_wrongindustry', enabled: true}}}, customElements: supported ? registry : undefined, isSecureContext: secure, navigator, addEventListener: (name, callback) => (windowEvents[name] ??= []).push(callback)};
  const document = {hidden: false, head,
    querySelector: selector => missingPanel && selector === '#barber-ai-panel' ? null : elements[selector] || null,
    createElement: tag => {const element = new Element(tag); if (tag === 'script') scripts.push(element); if (tag === 'elevenlabs-convai') widgets.push(element); return element;},
    addEventListener: (name, callback) => (events[name] ??= []).push(callback)
  };
  if (policy !== undefined) document.permissionsPolicy = {allowsFeature(name) {assert.equal(name, 'microphone'); if (policy === 'throw') throw new Error('Unsupported query'); return policy;}};
  const context = {window, document, navigator, location: {search: query},
    setTimeout: (callback, ms) => {const id = ++timerId; timers.set(id, {callback, ms}); return id;}, clearTimeout: id => timers.delete(id),
    fetch() {throw new Error('Adapter must not make direct API requests');}
  };
  vm.createContext(context); vm.runInContext(source, context);
  return {el: selector => elements[selector], head, scripts, widgets, timers, window, document, streams, copied, micArguments,
    open: () => elements['#barber-ai-open'].click(), close: () => elements['#barber-ai-close'].click(),
    define() {definitions.set('elevenlabs-convai', class {}); for (const waiter of definitionWaiters) waiter.resolve();},
    load() {this.define(); scripts.at(-1).trigger('load');}, timeout(ms) {for (const {callback, ms: duration} of [...timers.values()]) if (duration === ms) callback();},
    hide() {document.hidden = true; for (const callback of events.visibilitychange || []) callback();}, show() {document.hidden = false; for (const callback of events.visibilitychange || []) callback();}, pagehide() {for (const callback of windowEvents.pagehide || []) callback();},
    get guidedEnds() {return guidedEnds;}, get microphoneRequests() {return microphoneRequests;}
  };
}
const openReady = async h => {h.open(); await flush();};
async function run() {
  const idle = harness({query: '?industry=salon&agent-id=agent_wrongindustry'});
  assert.equal(idle.scripts.length, 0); assert.equal(idle.widgets.length, 0); assert.equal(idle.microphoneRequests, 0, 'No mic request on load'); assert.equal(idle.copied.length, 0, 'No clipboard access on load');
  assert.equal(idle.el('#barber-ai-open').getAttribute('aria-expanded'), 'false');
  idle.el('#guided-practice').open = true; idle.open();
  assert.equal(idle.guidedEnds, 1); assert.equal(idle.el('#guided-practice').open, false);
  assert.equal(idle.scripts.length, 0, 'No provider before asynchronous mic success');
  assert.equal(idle.el('#barber-ai-panel').dataset.state, 'checking'); assert.equal(idle.el('#barber-ai-panel').getAttribute('aria-busy'), 'true'); assert.equal(idle.el('#barber-ai-open').getAttribute('aria-expanded'), 'true');
  idle.open(); assert.equal(idle.microphoneRequests, 1, 'Repeated clicks cannot race'); await flush();
  assert.deepEqual(idle.micArguments[0], {audio: true});
  assert(idle.streams[0].tracks.every(track => track.stops === 1), 'All tracks stop before provider load');
  assert.equal(idle.scripts.length, 1); assert.equal(idle.scripts[0].src, SCRIPT); assert.equal(idle.el('#barber-ai-panel').dataset.state, 'loading');
  idle.load(); const widget = idle.widgets[0];
  for (const [attribute, value] of Object.entries({'agent-id': AGENT, 'text-input': 'false', 'persistent-session': 'false', variant: 'full', 'default-expanded': 'true'})) assert.equal(widget.getAttribute(attribute), value);
  assert(idle.el('#barber-ai-status').textContent.includes('Press Talk to the barber AI')); assert.equal(idle.el('#barber-ai-panel').dataset.state, 'open'); assert.equal(idle.el('#barber-ai-panel').getAttribute('aria-busy'), 'false'); assert.equal(idle.timers.size, 0);
  idle.close(); assert(widget.removed); assert.equal(idle.el('#barber-ai-mount').children.length, 0); assert.equal(idle.el('#barber-ai-open').getAttribute('aria-expanded'), 'false'); assert(idle.el('#barber-ai-open').focused);
  await openReady(idle); assert.equal(idle.microphoneRequests, 2, 'Every reopening rechecks mic permission'); assert.equal(idle.scripts.length, 1, 'Registered provider component can be reused');
  idle.hide(); assert(idle.widgets.at(-1).removed); const afterHide = idle.widgets.length; idle.show(); await flush(); assert.equal(idle.widgets.length, afterHide, 'No automatic reopening');
  await openReady(idle); idle.pagehide(); assert(idle.widgets.at(-1).removed);
  for (const control of ['#practice-start', '#practice-buttons']) {await openReady(idle); const active = idle.widgets.at(-1); idle.el(control).click(); assert(active.removed, 'Guided controller must close real AI');}
  for (const cancellation of ['close', 'hide', 'pagehide']) {
    const pending = deferred(), stream = microphoneStream(3, true), h = harness({getUserMedia: () => pending.promise});
    h.open(); h[cancellation](); pending.resolve(stream); await flush();
    assert(stream.tracks.every(track => track.stops === 1), cancellation + ': all late tracks released'); assert.equal(h.scripts.length, 0); assert.equal(h.widgets.length, 0); assert.equal(h.timers.size, 0); assert(h.el('#barber-mic-error').hidden, 'Cancellation is not a user error');
    h.show(); await flush(); assert.equal(h.microphoneRequests, 1, 'No automatic retry');
  }
  const first = deferred(), second = deferred(); let requests = 0;
  const timeout = harness({getUserMedia: () => (++requests === 1 ? first.promise : second.promise)});
  timeout.open(); timeout.timeout(20000);
  assert(timeout.el('#barber-mic-error-title').textContent.includes('timed out')); assert(timeout.el('#barber-mic-help').open); assert(timeout.el('#barber-mic-error-title').focused); assert.equal(timeout.scripts.length, 0);
  timeout.open(); assert(timeout.el('#barber-mic-error').hidden, 'Retry clears old error'); const late = microphoneStream(); first.resolve(late); await flush();
  assert(late.tracks.every(track => track.stops === 1)); assert.equal(timeout.scripts.length, 0, 'Late old permission cannot advance new attempt');
  const current = microphoneStream(); second.resolve(current); await flush(); assert(current.tracks.every(track => track.stops === 1)); assert.equal(timeout.scripts.length, 1); assert.equal([...timeout.timers.values()][0].ms, 25000);
  for (const [name, message, expected] of [['NotAllowedError', 'Permission denied by system', 'system blocked'], ['NotAllowedError', 'Permission denied', 'not granted'], ['NotFoundError', 'Requested device not found', 'No available microphone'], ['NotReadableError', 'Could not start audio source', 'could not be opened'], ['SecurityError', 'Disabled', 'browser blocked'], ['UnknownError', 'Unknown', 'did not finish']]) {
    const h = harness({getUserMedia: () => Promise.reject({name, message})}); await openReady(h);
    assert(h.el('#barber-mic-error-title').textContent.includes(expected), name + ' gets specific recovery'); assert(!h.el('#barber-mic-error').hidden); assert(h.el('#barber-mic-help').open); assert(h.el('#barber-mic-error-title').focused); assert.equal(h.scripts.length, 0, 'No provider on permission failure'); assert.equal(h.widgets.length, 0); assert.equal(h.timers.size, 0); assert(!h.el('#barber-ai-open').disabled); assert(h.el('#barber-ai-open').textContent.includes('Retry'));
  }
  const synchronousFailure = harness({getUserMedia() {throw {name: 'NotAllowedError', message: 'Permission denied by system'};}}); await openReady(synchronousFailure); assert(synchronousFailure.el('#barber-mic-error-title').textContent.includes('system blocked'));
  const rejectedLate = deferred(), quiet = harness({getUserMedia: () => rejectedLate.promise}); quiet.open(); quiet.hide(); rejectedLate.reject({name: 'NotAllowedError', message: 'Permission denied'}); await flush(); assert(quiet.el('#barber-mic-error').hidden, 'Late rejection cannot focus/show after leaving');
  for (const [options, expected] of [[{secure: false}, 'secure browser'], [{media: false}, 'cannot request'], [{policy: false}, 'page is blocked']]) {const h = harness(options); await openReady(h); assert(h.el('#barber-mic-error-title').textContent.includes(expected)); assert.equal(h.microphoneRequests, 0); assert.equal(h.scripts.length, 0);}
  const oldPolicy = harness({policy: 'throw'}); await openReady(oldPolicy); assert.equal(oldPolicy.scripts.length, 1, 'Unsupported policy query lets capture decide');
  const stale = harness(); await openReady(stale); const oldScript = stale.scripts[0], staleLoad = oldScript.onload, staleError = oldScript.onerror; stale.close(); assert(oldScript.removed); assert.equal(oldScript.onload, null); await openReady(stale); stale.define(); staleLoad(); staleError(); assert.equal(stale.widgets.length, 0); stale.scripts[1].trigger('load'); assert.equal(stale.widgets.length, 1);
  const asyncDefinition = harness(); await openReady(asyncDefinition); asyncDefinition.scripts[0].trigger('load'); asyncDefinition.close(); asyncDefinition.define(); await flush(); assert.equal(asyncDefinition.widgets.length, 0);
  const failure = harness(); await openReady(failure); failure.scripts[0].trigger('error'); assert(failure.el('#barber-mic-error-message').textContent.includes('could not load')); assert(failure.scripts[0].removed); await openReady(failure); failure.timeout(25000); assert(failure.el('#barber-mic-error-message').textContent.includes('too long')); assert(failure.scripts[1].removed); await openReady(failure); failure.load(); assert.equal(failure.widgets.length, 1);
  const loadingBackground = harness(); await openReady(loadingBackground); const delayedLoad = loadingBackground.scripts[0].onload; loadingBackground.hide(); loadingBackground.define(); delayedLoad(); assert.equal(loadingBackground.widgets.length, 0); assert.equal(loadingBackground.timers.size, 0);
  const permission = deferred(), changed = harness({getUserMedia: () => permission.promise}); changed.open(); changed.window.HELLODESK_CONFIG.voiceAgents.barber.enabled = false; const changedStream = microphoneStream(); permission.resolve(changedStream); await flush(); assert(changedStream.tracks.every(track => track.stops === 1)); assert.equal(changed.scripts.length, 0); assert(changed.el('#barber-ai-open').disabled);
  const changedLoading = harness(); await openReady(changedLoading); changedLoading.window.HELLODESK_CONFIG.voiceAgents.barber.enabled = false; changedLoading.load(); assert.equal(changedLoading.widgets.length, 0);
  for (const config of [null, {provider: 'other', agentId: AGENT, enabled: true}, {provider: 'elevenlabs', agentId: AGENT, enabled: false}, {provider: 'elevenlabs', agentId: 'https://example.com/injected.js', enabled: true}, {provider: 'elevenlabs', agentId: AGENT, enabled: 'true'}]) {const h = harness({config}); await openReady(h); assert(h.el('#barber-ai-open').disabled); assert.equal(h.microphoneRequests, 0); assert.equal(h.scripts.length, 0);}
  const unsupported = harness({supported: false}); await openReady(unsupported); assert.equal(unsupported.microphoneRequests, 0); assert(unsupported.el('#barber-ai-status').textContent.includes('unavailable'));
  const absent = harness({missingPanel: true}); await openReady(absent); assert.equal(absent.microphoneRequests, 0);
  const copy = harness({query: '?redirect=https://evil.example'}); copy.el('#barber-mic-copy').click(); await flush(); assert.deepEqual(copy.copied, [LIVE_URL]); assert(copy.el('#barber-mic-copy-status').textContent.includes('copied'));
  for (const clipboard of [false, 'reject']) {const manual = harness({clipboard}); manual.el('#barber-mic-copy').click(); await flush(); assert(manual.el('#barber-mic-link').focused); assert(manual.el('#barber-mic-link').selected); assert(manual.el('#barber-mic-copy-status').textContent.includes('Ctrl+C')); assert.equal(manual.microphoneRequests, 0);}
  console.log('PASS: explicit microphone preflight before provider; every track released; no recording/forwarding; every open rechecks; error classification, policy and retry; permission timeout and late close/hide/page-exit cleanup; barber-only provider and guided isolation; stale callbacks; accessible recovery and explicit canonical link copying. Capture/widget lifecycles mocked; no live or paid conversation started.');
}
run().catch(error => {console.error(error); process.exitCode = 1;});
