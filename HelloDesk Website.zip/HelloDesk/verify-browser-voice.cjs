const assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
function setup(){const instances=[],spoken=[],states=[],captions=[],errors=[],mic=[];let aborted=0,cancelled=0;const timers=new Map();let next=0;
 class Recognition{constructor(){instances.push(this)}start(){this.started=true}stop(){this.stopped=true}abort(){aborted++}}
 class Utterance{constructor(text){this.text=text}}
 const window={isSecureContext:true,SpeechRecognition:Recognition,SpeechSynthesisUtterance:Utterance,speechSynthesis:{getVoices:()=>[{name:'Test',lang:'en-GB',voiceURI:'test'}],speak:u=>spoken.push(u),cancel:()=>cancelled++}};
 const context={window,setTimeout:f=>{const id=++next;timers.set(id,f);return id},clearTimeout:id=>timers.delete(id)};vm.createContext(context);vm.runInContext(fs.readFileSync('dist/browser-voice.js','utf8'),context);
 const api=window.HelloDeskBrowserVoice,create=id=>api.create({businessId:id,onState:s=>states.push(s),onCaption:(r,t)=>captions.push([r,t]),onError:e=>errors.push(e),onMic:b=>mic.push(b)});
 return {api,create,instances,spoken,states,captions,errors,mic,window,timers,get aborted(){return aborted},get cancelled(){return cancelled}};
}
{
 const h=setup(),s=h.create('barber');assert(h.api.supported());assert.equal(h.instances.length,0,'No microphone on page load');s.listen();assert.equal(h.instances.length,1);const r=h.instances[0];assert.equal(h.states.at(-1),'permission');assert(!h.mic.includes(true),'No pretend microphone state');r.onaudiostart();assert.equal(h.states.at(-1),'listening');assert.equal(h.mic.at(-1),true);r.onresult({resultIndex:0,results:[Object.assign([{transcript:'How much is a haircut?'}],{isFinal:true})]});assert(r.stopped);assert.equal(h.spoken.length,0,'Wait until capture has ended before speaking');r.onend();assert.equal(h.spoken.length,1);assert(h.spoken[0].text.includes('twenty pounds'));assert.equal(h.mic.at(-1),false);assert.notEqual(h.states.at(-1),'speaking','Wait for actual playback');h.spoken[0].onstart();assert.equal(h.states.at(-1),'speaking');h.spoken[0].onend();assert.equal(h.states.at(-1),'paused');assert.equal(h.instances.length,1,'Never restart mic automatically');s.stop();assert.equal(h.mic.at(-1),false);
}
{
 const h=setup(),s=h.create('salon');s.hearExample();assert.equal(h.instances.length,0);assert(h.spoken[0].text.includes('Willow Hair'));const stale=h.spoken[0].onend;s.stop();assert(h.cancelled>0);const count=h.states.length;stale();assert.equal(h.states.length,count,'Ignore stale playback callbacks');
 s.listen();const r=h.instances[0],staleResult=r.onresult;r.onerror({error:'not-allowed'});assert.equal(h.errors.at(-1),'permission_denied');assert(h.aborted>0);staleResult({resultIndex:0,results:[Object.assign([{transcript:'hello'}],{isFinal:true})]});assert.equal(h.spoken.length,1,'No response after failure');
}
{
 const h=setup(),s=h.create('ecommerce');s.listen();for(const fn of [...h.timers.values()])fn();assert.equal(h.errors.at(-1),'timeout');assert(h.aborted>0);assert.equal(h.mic.at(-1),false);delete h.window.SpeechRecognition;assert(!h.api.supported());assert(h.api.canSpeak());
}
{
 const {api}=setup();for(const id of ['barber','salon','restaurant','cafe','shop','ecommerce','cleaning','gardening','trades']){assert(api.greeting(id).includes('fictional business'));assert(api.reply(id,'How much does it cost?').length>20);assert(api.reply(id,'When do you open?').includes('sample hours'));assert(api.reply(id,'Can I book an appointment?').length>20);assert(api.reply(id,'Tell me a joke').includes('temporary demo'));}assert(api.reply('restaurant','Do you have gluten free food?').includes('qualified team'));assert(api.reply('shop','Check live stock').includes('no access'));assert.notEqual(api.reply('barber','What are the prices?'),api.reply('salon','What are the prices?'));
}
console.log('PASS: all nine business samples; speech turn lifecycle; no automatic mic restart; actual audio-state events; no-mic example playback; cancellation; stale callback rejection; permission errors; timeout and unsupported-browser detection. Speech APIs mocked: real microphone/audio QA still required.');
