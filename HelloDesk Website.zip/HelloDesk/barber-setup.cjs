module.exports = ({P, esc, button, eyebrow}) => {
  const packages = P.categories.filter(category => ['ai-receptionist', 'bundles'].includes(category.id));
  const options = packages.map(category => `<optgroup label="${esc(category.name)}">${category.planIds.map(id => `<option value="${id}">${esc(P.byId[id].name)}</option>`).join('')}</optgroup>`).join('');
  const tests = [
    ['availability', 'Correct service, staff and time', 'Check a real calendar slot, service duration, opening hours, breaks and the requested member of staff.'],
    ['collision', 'No double booking', 'Try the same slot twice, including simultaneous requests. A slot must be checked again when the booking is created.'],
    ['confirmation', 'Confirmation follows calendar acceptance', 'Confirm that an appointment is described as booked only after the calendar accepts it. A failed or timed-out request must not become a confirmation.'],
    ['reschedule', 'Change the correct appointment', 'Identify the existing booking, check the new time, and verify the change in the calendar without leaving duplicate appointments.'],
    ['cancellation', 'Cancel the correct appointment', 'Check the booking identity and cancellation rules. Verify the intended appointment is cancelled and a retry does not affect another booking.'],
    ['handover', 'A clear route to the team', 'Test a transfer while staff can answer and while they cannot. Verify the agreed message-taking fallback and destination.'],
    ['failure', 'No availability or connection failure', 'Try a fully booked day and an unavailable booking service. The assistant should explain the limit and use the agreed next step.'],
    ['telephone', 'The real telephone journey', 'Call the actual business number from a mobile. Check forwarding, voice clarity, interruptions, ending the call and any agreed SMS confirmation.']
  ];
  return `<section class="wrap page-intro barber-setup-intro">
    <a class="breadcrumb" href="/industries/barbers.html">← Back to HelloDesk for barbers</a>
    ${eyebrow('YOUR SHOP. YOUR RULES. YOUR APPROVAL.')}
    <h1>Make it work<br><em>the way you work.</em></h1>
    <p class="intro">Outline your barber shop’s booking rules, choose a package and keep a clear checklist for the live setup. You decide what the receptionist should know and when it should ask your team.</p>
    <p class="barber-local-notice"><b>A private working sheet on this page.</b> Nothing is submitted to HelloDesk. Download a text copy before leaving; refreshing clears your entries. Don’t add passwords, API keys or customer records.</p>
  </section>
  <section class="wrap section top-none">
    <div class="barber-setup-shell">
      <nav class="barber-setup-progress" aria-label="Barber setup steps">
        <button type="button" data-barber-step-link="1" aria-current="step" disabled><span>01</span>Your shop</button>
        <button type="button" data-barber-step-link="2" disabled><span>02</span>Booking rules</button>
        <button type="button" data-barber-step-link="3" disabled><span>03</span>Review & tests</button>
      </nav>
      <form id="barber-setup-form" novalidate>
        <section data-barber-step="1" aria-labelledby="barber-step-title-1">
          <p class="eyebrow">01 / A CLEAR STARTING POINT</p><h2 id="barber-step-title-1" tabindex="-1">Start with your shop.</h2>
          <div class="barber-field-grid"><div><label for="barber-shop-name">Barber shop name <span>(optional)</span></label><input id="barber-shop-name" autocomplete="organization" maxlength="100" placeholder="Leave blank for a general setup worksheet"></div><div><label for="barber-platform">Current booking system <span>(optional)</span></label><input id="barber-platform" maxlength="100" placeholder="System name, paper diary, or not sure yet"><p class="barber-field-note">We check supported access before agreeing a connection. A system name is not proof of compatibility.</p></div></div>
          <label for="barber-package">Package of interest</label><select id="barber-package"><option value="">Not sure yet — discuss the fit</option>${options}</select>
          <p id="barber-package-summary" class="barber-package-summary" role="status" aria-live="polite">Choose a package to see its monthly price, setup fee and allowances. You can leave this open for discussion.</p>
          <details class="barber-setup-details"><summary>Existing number and website <span>(optional)</span></summary><div class="barber-field-grid"><div><label for="barber-business-number">Public business telephone number</label><input id="barber-business-number" type="tel" autocomplete="off" maxlength="40"><p class="barber-field-note">Number routing and any provider charges must be checked.</p></div><div><label for="barber-website">Current business website or booking link</label><input id="barber-website" type="text" maxlength="300" placeholder="Public address only"></div></div></details>
        </section>
        <section data-barber-step="2" aria-labelledby="barber-step-title-2">
          <p class="eyebrow">02 / THE DETAILS BEHIND A GOOD BOOKING</p><h2 id="barber-step-title-2" tabindex="-1">Set the boundaries.</h2>
          <p class="barber-panel-intro">Use your approved business information. Leave anything you haven’t agreed blank; it will be marked “To agree” in the brief.</p>
          <label for="barber-services">Services, prices and appointment lengths</label><textarea id="barber-services" rows="4" maxlength="1800" placeholder="List the services callers can book, their prices and time needed. Include who can provide each service."></textarea>
          <label for="barber-availability">Staff calendars, hours and booking limits</label><textarea id="barber-availability" rows="4" maxlength="1800" placeholder="Opening hours, each barber’s availability, breaks, time between appointments, walk-ins and how far ahead a customer can book."></textarea>
          <label for="barber-changes">Changes, cancellations and deposits</label><textarea id="barber-changes" rows="4" maxlength="1800" placeholder="Your rules for changing or cancelling, identifying an existing booking, late arrivals and any deposit policy. Payment links need an agreed workflow; never take card details in this sheet."></textarea>
          <label for="barber-fallback">When the receptionist should ask your team</label><textarea id="barber-fallback" rows="4" maxlength="1800" placeholder="Who handles an unknown answer, complaint, fully booked day or failed connection? Note a public transfer destination and what to do when nobody answers."></textarea>
          <details class="barber-setup-details"><summary>Voice, messages and website requirements <span>(optional)</span></summary><label for="barber-preferences">Your greeting and other preferences</label><textarea id="barber-preferences" rows="4" maxlength="1500" placeholder="Preferred greeting and pronunciation, messages you want sent, or website pages and content if you are considering a bundle."></textarea><p class="barber-field-note">SMS, extra usage and website scope follow the selected package. Recording, transcript retention and caller notices need to be agreed before activation.</p></details>
        </section>
        <section data-barber-step="3" aria-labelledby="barber-step-title-3">
          <p class="eyebrow">03 / REVIEW BEFORE GO-LIVE</p><h2 id="barber-step-title-3" tabindex="-1">A setup you can check.</h2>
          <p class="barber-panel-intro">Review your working brief, then use the scenarios below with the team. A polished demo is only one part of testing a real telephone and booking connection.</p>
          <dl id="barber-review" class="barber-review"></dl>
          <details class="barber-setup-details"><summary>Live acceptance checks <span>8 scenarios · manually reported</span></summary>
            <p class="barber-test-explainer">These tests do not run on this website. Every result starts as <b>Not yet tested</b>. Change a result only after a person checks the real connected service. A marked result is a review note, not independent verification or activation.</p>
            <div class="barber-test-list">${tests.map(([id, title, detail], index) => `<article class="barber-test-item"><div><p class="barber-test-number">${String(index + 1).padStart(2, '0')}</p><h3>${esc(title)}</h3><p>${esc(detail)}</p></div><div><label for="barber-test-${id}">Review result: ${esc(title)}</label><select id="barber-test-${id}" data-barber-test="${id}" data-test-name="${esc(title)}"><option value="not-tested">Not yet tested</option><option value="passed">Manually checked — passed</option><option value="needs-work">Needs work</option></select></div></article>`).join('')}</div>
          </details>
          <label for="barber-test-notes">Test notes and outstanding decisions <span>(optional)</span></label><textarea id="barber-test-notes" rows="3" maxlength="1800" placeholder="Record what was checked, when, and anything still needing attention. Do not include real customer records."></textarea>
          <p id="barber-test-status" class="barber-test-status" role="status" aria-live="polite">Live setup has not been verified by this website.</p>
          <div class="barber-review-actions"><button id="barber-download" type="button" class="button dark" disabled>Download shop brief & checklist <span aria-hidden="true">↓</span></button><a class="button outline" href="/practice-booking.html?industry=barber#barber-ai">Try the practice voice demo <span aria-hidden="true">↗</span></a></div>
          <p class="barber-field-note">The download is a working document, not an order, agreement, appointment or launch approval. ${esc(P.terms.receptionistSetup)} ${esc(P.vatNote)}</p>
        </section>
        <p id="barber-setup-error" class="barber-setup-error" role="alert" tabindex="-1" hidden></p>
        <div id="barber-step-navigation" class="barber-step-navigation" hidden><button type="button" id="barber-back" class="button outline">Back</button><button type="button" id="barber-next" class="button dark">Next: booking rules <span aria-hidden="true">↗</span></button><p id="barber-step-status" role="status" aria-live="polite">Step 1 of 3</p></div>
        <div class="barber-setup-bottom"><button type="button" id="barber-reset" class="barber-reset" disabled>Clear this working sheet</button><p id="barber-save-status" role="status" aria-live="polite">Page-only. Nothing has been sent or saved by HelloDesk.</p></div>
      </form>
      <noscript><p class="notice">You can read all sections without JavaScript. Enable JavaScript to move between steps, see package details and download your local brief.</p></noscript>
    </div>
    <div class="barber-setup-links">${button('/industries/barbers.html', 'Back to the barber service', true)}<a class="textlink" href="/pricing.html">Compare every package →</a></div>
  </section>`;
};
