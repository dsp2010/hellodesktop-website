const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

class Element {
  constructor() { this.value = ''; this.textContent = ''; this.hidden = false; this.disabled = true; this.events = {}; this.children = []; this.dataset = {}; }
  addEventListener(event, callback) { (this.events[event] ??= []).push(callback); }
  fire(event, properties = {}) { return Promise.all((this.events[event] || []).map(callback => callback({target: this, preventDefault() {}, ...properties}))); }
  append(...children) { this.children.push(...children); }
  replaceChildren(...children) { this.children = children; }
  reportValidity() { return true; }
  reset() {}
}
function load(context, files) {
  vm.createContext(context);
  for (const name of files) vm.runInContext(fs.readFileSync('dist/' + name, 'utf8'), context, {filename: name});
}
const dataFiles = ['packages.js', 'config.js', 'content.js'];
function preview(search) {
  const selectors = ['#personalise-form', '#preview-cover', '#preview-type', '#preview-greeting', '#preview-question', '#preview-answer', '#preview-notes', '#preview-name', '#preview-business-label', '#preview-industry-label', '#preview-greeting-label', '#preview-question-label', '#preview-answer-label', '#preview-answer-heading', '#preview-pricing', '#preview-guide', '#preview-reset', '#brief-download', '#brief-status', '#preview-usage', '#brief-package', '#brief-package-summary', '#brief-phone-fields', '#brief-call-preview', '#brief-preview-jump', '#preview-call-examples', '#brief-layout', '#brief-introduction', '#brief-package-pricing'];
  const elements = new Map(selectors.map(selector => [selector, new Element()]));
  elements.get('#preview-cover').value = 'When the team is busy';
  let saved, clicks = 0;
  class LocalURL extends URL {}
  LocalURL.createObjectURL = blob => { saved = blob; return 'blob:local-brief'; };
  LocalURL.revokeObjectURL = () => {};
  const context = {window: {}, document: {querySelector: selector => elements.get(selector) || null, body: {append() {}}, createElement: () => ({click() { clicks++; }, remove() {}})}, location: {search}, URLSearchParams, URL: LocalURL, Blob, setTimeout: () => 1, fetch() {throw new Error('Local brief must never send details');}};
  load(context, [...dataFiles, 'setup-core.js', 'experience.js']);
  return {el: selector => elements.get(selector), P: context.window.HELLODESK_PACKAGES, async download() { await elements.get('#brief-download').fire('click'); assert(saved); assert(clicks); return saved.text(); }};
}
function enquiry({search = '', connected = false, accepted = true} = {}) {
  const selectors = ['#booking-form', '#booking-group', '#booking-type', '#booking-package', '#booking-package-summary', '#booking-fields', '#booking-submit', '#booking-notice', '#booking-privacy', '#booking-result', '#calendar-link'];
  const elements = new Map(selectors.map(selector => [selector, new Element()]));
  const requests = [];
  const context = {
    window: {}, document: {body: {dataset: {industry: 'barber'}}, querySelector: selector => elements.get(selector) || null, querySelectorAll: () => [], addEventListener() {}, createElement: () => new Element()},
    location: {search, pathname: '/book-demo.html', href: 'https://example.com/book-demo.html' + search}, URL, URLSearchParams, Option: function(text, value) {this.text = text; this.value = value;},
    FormData: class { *[Symbol.iterator]() {yield ['name', 'Example person']; yield ['plan', '__proto__']; yield ['package', 'untrusted form value'];} },
    AbortController, setTimeout: () => 1, clearTimeout() {},
    fetch: async (url, options) => {requests.push({url, body: JSON.parse(options.body)}); return {ok: true, json: async () => accepted ? {accepted: true, reference: 'DEMO-123'} : {accepted: false}};}
  };
  load(context, dataFiles);
  if (connected) {
    Object.assign(context.window.HELLODESK_CONFIG.booking, {endpoint: 'https://example.com/enquiries', responseMessage: 'We will respond through the agreed contact route.'});
    context.window.HELLODESK_CONFIG.terms.privacyUrl = 'https://example.com/privacy';
  }
  vm.runInContext(fs.readFileSync('dist/site.js', 'utf8'), context, {filename: 'site.js'});
  return {el: selector => elements.get(selector), requests, P: context.window.HELLODESK_PACKAGES};
}
async function main() {
  const catalogue = preview('').P;
  assert.equal(catalogue.packages.length, 10);
  for (const plan of catalogue.packages) {
    const h = preview('?industry=salon&plan=' + plan.id + '&calls=20&length=2.5&days=24');
    assert.equal(h.el('#brief-package').value, plan.id);
    assert.equal(h.el('#brief-package-summary').textContent, h.P.summary(plan.id).join(' '));
    const websiteOnly=plan.category==='websites';
    assert.equal(h.el('#brief-layout').dataset.packageMode,websiteOnly?'website':'receptionist');
    for(const selector of ['#brief-phone-fields','#brief-call-preview','#brief-preview-jump','#preview-guide','#preview-call-examples'])assert.equal(h.el(selector).hidden,websiteOnly);
    assert.equal(h.el('#preview-usage').hidden,websiteOnly);
    assert.equal(h.el('#preview-notes').hidden,false);
    assert.equal(new URL(h.el('#preview-pricing').href, 'https://example.com').searchParams.get('plan'), plan.id);
    h.el('#preview-name').value = 'Willow & <Co>';
    await h.el('#personalise-form').fire('input');
    const text = await h.download();
    assert(text.includes('Business: Willow & <Co>'));
    assert(text.includes(`Package of interest: ${plan.name} (${plan.id})`));
    for (const detail of h.P.summary(plan.id)) assert(text.includes(detail));
    assert(text.includes('has not been sent to HelloDesk'));
  }
  const changed = preview('?industry=barber&plan=bundle-pro');
  changed.el('#brief-package').value = 'web-business';
  changed.el('#preview-notes').value = 'Five pages with our own photographs.';
  await changed.el('#brief-package').fire('change');
  const changedText = await changed.download();
  assert(changedText.includes('web-business'));
  assert(!changedText.includes('bundle-pro'));
  assert(!changedText.includes('Opening greeting:'));
  assert(changedText.includes('Five pages with our own photographs.'));
  changed.el('#brief-package').value = '';
  await changed.el('#brief-package').fire('change');
  assert((await changed.download()).includes('Package of interest: To be discussed.'));
  const mode = preview('?plan=web-business&calls=20&length=2.5&days=24');
  mode.el('#preview-greeting').value='Our saved telephone draft';
  mode.el('#preview-notes').value='Our saved website notes';
  assert(mode.el('#brief-introduction').textContent.includes('website setup brief'));
  assert(!new URL(mode.el('#brief-package-pricing').href,'https://example.com').searchParams.has('calls'));
  mode.el('#brief-package').value='ai-growth';
  await mode.el('#brief-package').fire('change');
  assert.equal(mode.el('#brief-phone-fields').hidden,false);
  assert.equal(mode.el('#brief-call-preview').hidden,false);
  assert.equal(mode.el('#preview-usage').hidden,false);
  assert.equal(mode.el('#preview-greeting').value,'Our saved telephone draft');
  assert.equal(mode.el('#preview-notes').value,'Our saved website notes');
  mode.el('#brief-package').value='web-launch';
  await mode.el('#brief-package').fire('change');
  assert.equal(mode.el('#brief-call-preview').hidden,true);
  mode.el('#brief-package').value='bundle-pro';
  await mode.el('#brief-package').fire('change');
  assert.equal(mode.el('#brief-call-preview').hidden,false);
  assert.equal(mode.el('#preview-greeting').value,'Our saved telephone draft');
  const unknown = preview('?plan=__proto__');
  assert.equal(unknown.el('#brief-package').value, '');
  assert((await unknown.download()).includes('Package of interest: To be discussed.'));

  const offline = enquiry({search: '?plan=ai-essential'});
  await offline.el('#booking-form').fire('submit');
  assert.equal(offline.requests.length, 0, 'Unconfigured forms never submit');
  assert(offline.el('#booking-fields').disabled);
  const online = enquiry({search: '?plan=ai-growth', connected: true});
  assert.equal(online.el('#booking-package').value, 'ai-growth');
  assert.equal(online.el('#booking-fields').disabled, false);
  online.el('#booking-package').value = 'bundle-essential';
  await online.el('#booking-package').fire('change');
  assert.equal(online.el('#booking-package-summary').textContent, online.P.summary('bundle-essential').join(' '));
  await online.el('#booking-form').fire('submit');
  assert.equal(online.requests.length, 1);
  const body = online.requests[0].body;
  assert.equal(body.plan, 'bundle-essential');
  assert.equal(body.packageCategory, 'bundles');
  assert.equal(body.currency, 'GBP');
  assert.deepEqual(body.package, JSON.parse(JSON.stringify(online.P.snapshot('bundle-essential'))));
  assert.deepEqual(body.packageSummary, Array.from(online.P.summary('bundle-essential')));
  assert(online.el('#booking-result').textContent.includes('DEMO-123'));
  const rejected = enquiry({connected: true, accepted: false});
  await rejected.el('#booking-form').fire('submit');
  assert(rejected.el('#booking-result').textContent.includes('could not confirm delivery'));
  assert.equal(rejected.el('#booking-submit').disabled, false);
  console.log('PASS: all ten package selections retain shared prices, setup and allowances in local briefs; dropdown changes, unknown IDs and website-only exports; enquiries stay disabled without a receiver and require real acceptance with canonical package snapshots. No live network, payments, microphone or bookings used.');
}
main().catch(error => {console.error(error); process.exitCode = 1;});
