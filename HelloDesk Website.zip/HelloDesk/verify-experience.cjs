const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
async function main(){
 const elements=new Map(),callbacks={},styles={};let savedBlob,clicked=false;
 const el=id=>{if(!elements.has(id))elements.set(id,{value:'',textContent:'',hidden:false,dataset:{},style:{setProperty:(k,v)=>styles[k]=v},addEventListener:(event,f)=>{callbacks[id+':'+event]=f}});return elements.get(id)};
 el('#preview-cover').value='When the team is busy';
 const window={},document={querySelector:s=>['#usage-form','#booking-preview-link'].includes(s)?null:el(s),body:{append(){}},createElement:()=>({click(){clicked=true},remove(){}})};
 const U=class extends URL{};U.createObjectURL=b=>{savedBlob=b;return 'blob:test'};U.revokeObjectURL=()=>{};
 const ctx={window,document,location:{search:'?industry=salon&plan=ai-growth&calls=20&length=2.5&days=24&coverage=closed&number=existing&goals=booking,transfer'},URLSearchParams,URL:U,Blob,setTimeout:()=>{}};vm.createContext(ctx);
 for(const f of ['packages.js','config.js','content.js','setup-core.js','experience.js'])vm.runInContext(fs.readFileSync('dist/'+f,'utf8'),ctx);
 el('#preview-name').value='Willow & <Co>';el('#preview-answer').value='Our confirmed hours are 9am–5pm.';callbacks['#personalise-form:input']();
 assert.equal(el('#preview-business-label').textContent,'Willow & <Co>');
 callbacks['#brief-download:click']();assert(clicked);const exported=await savedBlob.text();assert(exported.includes('Business type: Hair & beauty salons (salon)'));assert(exported.includes('Willow & <Co>'));assert(exported.includes('1,200 minutes/month'));assert.equal(el('#brief-package').value,'ai-growth');for(const line of window.HELLODESK_PACKAGES.summary('ai-growth'))assert(exported.includes(line));assert(exported.includes('has not been sent to HelloDesk'));assert(exported.includes('Preferred coverage: Outside opening hours'));assert(exported.includes('Discuss handoff to the team'));assert(exported.includes('Review my existing business number'));
 el('#preview-type').value='restaurant';callbacks['#preview-type:change']();assert.equal(el('#preview-answer').value,'');assert.equal(el('#preview-question').value,'Where can I see the menu?');
 assert.equal(el('#preview-business-label').textContent,'Willow & <Co>');
 console.log('PASS: local brief export preserves business, industry, plan and usage; industry changes clear stale answers. No network or microphone used.');
}main().catch(e=>{console.error(e);process.exitCode=1});
