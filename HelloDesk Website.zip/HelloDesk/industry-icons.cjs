const paths={
 barber:'<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="m8 8 13 13M8 16 21 3M14 10l-3 3"/>',
 salon:'<path d="M12 3c1 4 3 6 7 7-4 1-6 3-7 7-1-4-3-6-7-7 4-1 6-3 7-7ZM19 16v6M16 19h6M4 2v4M2 4h4"/>',
 restaurant:'<path d="M5 3v5a3 3 0 0 0 6 0V3M8 3v18M18 3c-3 4-4 8 0 9h2V3h-2ZM20 12v9"/>',
 cafe:'<path d="M4 9h12v6a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5V9ZM16 10h2a3 3 0 0 1 0 6h-2M3 22h15M7 3v2M12 2v3"/>',
 shop:'<path d="m3 9 2-6h14l2 6v3a3 3 0 0 1-6 0 3 3 0 0 1-6 0 3 3 0 0 1-6 0V9ZM5 15v6h14v-6M9 21v-5h6v5M3 9h18"/>',
 ecommerce:'<path d="M4 7h16l-1 14H5L4 7ZM8 8V6a4 4 0 0 1 8 0v2M9 13l2 2 4-4"/>',
 cleaning:'<path d="m15 3-4 9M7 12h7l4 9H3l4-9ZM8 16l-1 5M12 16v5M19 3v4M17 5h4"/>',
 gardening:'<path d="M20 3C9 2 3 7 5 14c6 6 14 0 15-11ZM4 21l11-12M5 15l6-1"/>',
 trades:'<path d="m14 6 4-4a6 6 0 0 0-7 8L3 18a2 2 0 0 0 3 3l8-8a6 6 0 0 0 8-7l-4 4-4-4Z"/>',
 phone:'<path d="M7 3H4a1 1 0 0 0-1 1c0 9.4 7.6 17 17 17a1 1 0 0 0 1-1v-3l-5-2-2 2a15 15 0 0 1-7-7l2-2-2-5Z"/><path d="M14 4a6 6 0 0 1 6 6M14 8a2 2 0 0 1 2 2"/>'
};
module.exports=id=>`<svg class="line-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.55" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[id]||paths.phone}</svg>`;
