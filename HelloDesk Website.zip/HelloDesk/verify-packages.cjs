const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = __dirname;
const source = fs.readFileSync(path.join(root, 'dist/packages.js'), 'utf8');
const plain = value => JSON.parse(JSON.stringify(value));
function load() {
  const context = {window: {}};
  vm.createContext(context);
  vm.runInContext(source, context);
  return {context, P: context.window.HELLODESK_PACKAGES};
}
const {context, P} = load();

// Independent fixtures transcribed from the supplied commercial brief.
const ai = [
  ['ai-essential', 'Essential Receptionist', 199, 299, 250, 100, 1, 0.49, 1],
  ['ai-growth', 'Growth Receptionist', 349, 499, 750, 300, 3, 0.45, 2],
  ['ai-pro', 'Pro Receptionist', 599, 699, 1500, 600, 6, 0.39, 3],
  ['ai-plus', 'Plus Receptionist', 999, 999, 3000, 1200, 10, 0.35, 4]
];
const websites = [
  ['web-launch', 'Launch Website', 99, 299, 1, 30, 2, 12],
  ['web-business', 'Business Website', 149, 499, 5, 60, 2, 12],
  ['web-growth', 'Growth Website', 249, 999, 10, 120, 3, 12]
];
const bundles = [
  ['bundle-essential', 'Essential Bundle', 279, 499, 'ai-essential', 'web-launch', 19, 12],
  ['bundle-growth', 'Growth Bundle', 479, 799, 'ai-growth', 'web-business', 19, 12],
  ['bundle-pro', 'Pro Bundle', 799, 1299, 'ai-pro', 'web-growth', 49, 12]
];
const packageIds = [...ai, ...websites, ...bundles].map(row => row[0]);
assert.equal(P.currency, 'GBP');
assert.deepEqual(plain(P.packages.map(p => p.id)), packageIds, 'Exactly the ten specified packages are offered');
assert.deepEqual(Object.keys(P.byId), packageIds);
for (const [id, ...expected] of ai) {
  const plan = P.byId[id];
  assert.equal(plan.category, 'ai-receptionist');
  assert.deepEqual(['name', 'monthly', 'setup', 'minutes', 'sms', 'calendars', 'extraMinute', 'infoUpdates'].map(key => plan[key]), expected, id);
  assert.equal(plan.recommended, id === 'ai-growth');
}
for (const [id, ...expected] of websites) {
  const plan = P.byId[id];
  assert.equal(plan.category, 'websites');
  assert.deepEqual(['name', 'monthly', 'setup', 'pages', 'editMinutes', 'revisions', 'initialTermMonths'].map(key => plan[key]), expected, id);
  assert.equal(plan.recommended, false, 'No unsupported website recommendation is added');
}
for (const [id, ...expected] of bundles) {
  const plan = P.byId[id];
  assert.equal(plan.category, 'bundles');
  assert.deepEqual(['name', 'monthly', 'setup', 'receptionistId', 'websiteId', 'savingMonthly', 'initialTermMonths'].map(key => plan[key]), expected, id);
  assert.equal(plan.recommended, id === 'bundle-growth');
  for (const key of ['minutes', 'sms', 'calendars', 'extraMinute', 'infoUpdates', 'pages', 'editMinutes', 'revisions']) assert.equal(Object.hasOwn(plan, key), false, 'Bundles reference component allowances rather than copying them');
  assert.strictEqual(P.receptionistFor(id), P.byId[plan.receptionistId]);
  assert.strictEqual(P.websiteFor(id), P.byId[plan.websiteId]);
  const snapshot = P.snapshot(id);
  assert.equal(snapshot.receptionist.id, plan.receptionistId);
  assert.equal(snapshot.website.id, plan.websiteId);
  assert.deepEqual(plain(snapshot.receptionist), plain(P.byId[plan.receptionistId]));
  assert.deepEqual(plain(snapshot.website), plain(P.byId[plan.websiteId]));
}

const addOns = {
  'extra-sms': {price: 15, quantity: 100, unit: 'segments', display: '£15 per 100 segments'},
  'staff-calendar': {setup: 99, monthly: 15, display: '£99 setup + £15/month'},
  'payment-workflow': {setup: 199, monthly: 29, display: '£199 setup + £29/month'},
  'location': {setup: 199, monthly: 99, from: true, display: 'From £199 setup + £99/month'},
  'website-page': {price: 99, display: '£99'},
  'support': {price: 60, unit: 'hour', minimumMinutes: 30, display: '£60/hour'},
  'email': {price: 49, display: '£49'},
  'booking-integration': {setup: 299, from: true, display: 'From £299 setup'},
  'voice-widget': {setup: 99, display: '£99 setup'},
  'human-transfer': {price: 0.12, unit: 'minute', display: '£0.12/minute'}
};
assert.deepEqual(plain(P.addOns.map(service => service.id)), Object.keys(addOns), 'All ten optional services are present');
for (const [id, fixture] of Object.entries(addOns)) {
  const actual = P.addOns.find(service => service.id === id);
  for (const [key, value] of Object.entries(fixture).filter(([key]) => key !== 'display')) assert.equal(actual[key], value, `${id}: ${key}`);
  assert.equal(P.addOnPrice(actual), fixture.display, id + ' displayed charge');
  for (const field of ['price', 'setup', 'monthly', 'quantity', 'minimumMinutes']) if (!Object.hasOwn(fixture, field)) assert.equal(actual[field], undefined, id + ': no unsupported extra fee');
}
assert.deepEqual(plain(P.outright.map(offer => [offer.pages, offer.from])), [[1, 799], [5, 1499], [10, 2499]]);
assert.equal(P.terms.websiteInitialTermMonths, 12);
assert.equal(P.terms.renewalNoticeDays, 30);
assert.equal(P.terms.domainAnnualAllowance, 25);
assert.equal(P.vatNote, 'VAT added where applicable.');
assert.match(P.terms.receptionistSetup, /paid before building/);
assert.match(P.terms.receptionistSetup, /subscription starts at the agreed go-live date/i);
assert.match(P.terms.availability, /around the clock, subject to service availability/);
assert.match(P.terms.availability, /Human support operates during agreed business hours/);

// The public config and industry data consume the catalogue, not parallel prices.
vm.runInContext(fs.readFileSync(path.join(root, 'dist/config.js'), 'utf8'), context);
vm.runInContext(fs.readFileSync(path.join(root, 'dist/content.js'), 'utf8'), context);
const C = context.window.HELLODESK_CONFIG, D = context.window.HELLODESK_CONTENT;
assert.strictEqual(C.plans, P.byId);
for (const id of packageIds) {
  assert.equal(C.prices[id], P.byId[id].monthly);
  assert.equal(D.planLabels[id][0], P.byId[id].name);
  const summary = P.summary(id).join('\n');
  assert(summary.includes(P.money(P.byId[id].monthly)) && summary.includes(P.money(P.byId[id].setup)), id + ': brief has monthly and setup prices');
  assert(summary.includes(P.vatNote), id + ': brief has VAT note');
}
const changed = load();
changed.P.byId['ai-growth'].monthly = 357;
changed.P.byId['ai-growth'].minutes = 751;
vm.runInContext(fs.readFileSync(path.join(root, 'dist/config.js'), 'utf8'), changed.context);
assert.equal(changed.context.window.HELLODESK_CONFIG.prices['ai-growth'], 357, 'Changing the catalogue changes the consumer price');
assert.equal(changed.P.snapshot('bundle-growth').receptionist.minutes, 751, 'Bundle snapshots inherit a changed component allowance');
assert(changed.P.describe('bundle-growth').some(line => line.includes('751 AI minutes')), 'Bundle brief inherits the same updated component');

const esc = value => String(value ?? '').replace(/[&<>"']/g, character => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[character]));
const body = require('./pricing-page.cjs')({P, esc, button: (href, label) => `<a href="${esc(href)}">${esc(label)}</a>`, eyebrow: text => `<p>${esc(text)}</p>`, faq: items => items.map(([question, answer]) => `<details><summary>${esc(question)}</summary><p>${esc(answer)}</p></details>`).join('')});
assert.equal((body.match(/<h1[ >]/g) || []).length, 1);
const ids = [...body.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]);
assert.equal(ids.length, new Set(ids).size, 'Rendered pricing has no duplicate IDs');
for (const category of ['AI Receptionist', 'Websites', 'Receptionist + Website Bundles']) assert(body.includes(esc(category)), 'Category label: ' + category);
for (const plan of P.packages) {
  const article = body.match(new RegExp('<article[^>]*id="package-' + plan.id + '"[\\s\\S]*?<\\/article>'))?.[0];
  assert(article, 'Pricing card: ' + plan.id);
  assert(article.includes(P.money(plan.monthly)), plan.id + ': monthly price');
  assert(article.includes(P.money(plan.setup) + ' one-time setup'), plan.id + ': setup fee');
  assert.match(article, /class="package-monthly">[\s\S]*?<\/p>\s*<p class="package-setup">/, 'Setup fee immediately follows monthly price');
  assert(article.includes(P.vatNote), plan.id + ': visible VAT note');
  assert(article.includes('/personalise.html?plan=' + plan.id), plan.id + ': local brief selection');
  assert.equal(article.includes('>Recommended<'), plan.recommended, plan.id + ': recommendation label');
  if (plan.initialTermMonths) assert(article.includes('12-month initial term') && article.includes('30 days’ notice'), plan.id + ': commitment near price');
  const receptionist = P.receptionistFor(plan.id);
  if (receptionist) assert(article.includes(P.money(receptionist.extraMinute)), plan.id + ': extra minute rate visible');
  if (plan.category === 'bundles') assert(article.includes('Save ' + P.money(plan.savingMonthly) + '/month'), plan.id + ': accurate monthly saving');
}
for (const {display} of Object.values(addOns)) assert(body.includes(esc(display)), 'Rendered optional charge: ' + display);
for (const offer of P.outright) assert(body.includes(P.money(offer.from)), 'Rendered outright price');
assert(!/most popular|unlimited|\bstarter\b|\bscale\b/i.test(body), 'No conflicting old plans or unsupported claims');
assert(body.includes('not connected yet') && body.includes('nothing is ordered, booked or submitted'), 'Choosing a package does not falsely submit an enquiry or take payment');
assert(body.includes('Card details are not collected verbally'), 'Payment links are hosted, not verbal card collection');

const build = fs.readFileSync(path.join(root, 'build.cjs'), 'utf8');
const catalogueTag = '<script src="/packages.js" defer></script>';
assert.equal(build.split(catalogueTag).length - 1, 1, 'Shared shell loads the catalogue exactly once');
assert(build.indexOf(catalogueTag) < build.indexOf('<script src="/config.js"'), 'Browser catalogue loads before config consumers');
assert.match(build, /\['packages\.js','config\.js','content\.js'\]/, 'Build uses the same ordered catalogue source');

console.log('PASS: ten exact packages; all AI/website allowances; inherited bundle limits and savings; ten add-on charges; outright prices; shared catalogue consumers and briefs; visible setup/VAT/term/recommendation details. No checkout or provider call used.');
