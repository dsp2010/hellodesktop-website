# HelloDesk

Static sales website for UK AI telephone receptionists, custom-coded websites and bundles. The existing HelloDesk name, green/cream design, navigation, industry examples and barber voice demonstration are retained.

## Shared package data

Maintain all package prices, allowances, bundle components/savings, add-ons, outright offers and numeric service terms in dist/packages.js. It exposes HELLODESK_PACKAGES to the browser and build. dist/config.js derives public price/plan aliases from that catalogue; dist/content.js derives package labels. Load packages.js before configuration and content. Never maintain a second numeric price table in templates or runtime controllers.

pricing-page.cjs renders the three pricing categories, clear setup fees, usage charges, common features, comparison tables, terms, extras and FAQs. dist/pricing.css supplies its responsive styles. Growth Receptionist and Growth Bundle are marked Recommended; no sales-popularity claim is made.

## Build and preview

Use current supported Node.js, with no external packages required:

    node build.cjs
    node verify.cjs
    node verify-packages.cjs
    node verify-package-flow.cjs
    node preview.cjs

Open http://127.0.0.1:4318. Build produces 26 HTML pages and the favicon in dist/. Edit root builder modules and dist JS/CSS, then rebuild; do not edit generated HTML alone. The static hosting manifest keeps the existing project identity. Preserve its existing audience when publishing.

## Barber experience

home-hub.cjs keeps six direct destinations on the compact homepage. barber-page.cjs renders the specialist page at the existing /industries/barbers.html route. voice-practice-page.cjs supplies the practical voice-demo walkthrough while dist/elevenlabs-voice.js retains the provider and microphone lifecycle. dist/barber-quality.css and dist/client-quality.css provide the presentation and readable controls.

barber-setup.cjs and dist/barber-setup.js implement a generic three-step, page-only shop worksheet at /barber-setup.html. It exports supplied booking rules and shared package allowances plus eight manually reported checks, initially NOT YET TESTED. It does not run integration tests, send enquiries, store entries or activate a service. No prospect-specific shop details have been added.

Run node verify-barber-setup.cjs for worksheet behavior and node verify-barber-quality.cjs for unchanged commercial data, navigation targets and page-specific assets. The latter enforces the complete package catalogue's SHA256 from before this presentation upgrade. A commercial change must be explicitly authorized before updating that baseline.

The page shell loads only four scripts on the homepage. Feature scripts and styles load on the pages that use them. Keep packages.js before config.js and content.js, and keep the browser-speech adapter before site.js on the older demo page.

## Setup brief and enquiry flow

The pricing CTAs lead to /personalise.html?plan=<canonical-package-id>. The brief offers all ten packages, shows the shared catalogue summary, and exports the currently selected package and allowances. Website-only selections omit telephone details. Business information stays in the page and downloaded file; it is not sent to HelloDesk.

A configured enquiry receiver can receive the canonical package ID, category, public data snapshot and human-readable summary. No receiver or booking calendar is currently supplied, so the enquiry form remains disabled/hidden. Never infer acceptance from navigation or a network request alone.

## Payments and live integrations

The owner supplied commercial scope and package terms, but no Stripe Payment Links, public contact email, booking calendar, complete service agreement or actual enquiry endpoint. salesOpen remains false. Configure only public Stripe-hosted URLs in config.js; keep secret keys on a server. Hosted checkout must collect the correct setup fee and monthly subscription with the agreed go-live start. A monthly link by itself does not implement this sequence. Payment-return.html never verifies payment or provisions service.

One real ElevenLabs barber browser demonstration is connected through dist/elevenlabs-voice.js and voice-practice-page.cjs. Its public agent identifier and provider domain allowlist remain unchanged. Other industries use fictional/scripted examples. The website source does not contain a live telephone number, calendar booking workflow, n8n credentials or real payment integration. The published package scope requires supported integrations to be configured and tested for each customer before go-live.

## Additional verification

    node verify-sales.cjs
    node verify-experience.cjs
    node verify-setup.cjs
    node verify-elevenlabs-voice.cjs
    node verify-practice-booking.cjs
    node verify-browser-voice.cjs

Automated checks use static inspection and mocked browser/provider APIs. They do not make live payments, bookings or voice calls, and do not establish device microphone availability or voice quality. See INTEGRATION-GUIDE.md for the retained voice integration contracts and provider details.
